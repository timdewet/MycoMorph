"""Main window — sidebar nav across stages, orchestrates RunContext + PipelineRunner."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from PyQt6.QtCore import QByteArray, QSettings, QSize, Qt as _Qt, QTimer, QUrl
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QDesktopServices, QIcon, QPainter, QPixmap
from PyQt6.QtSvg import QSvgRenderer
from PyQt6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSplitter,
    QStackedWidget,
    QStatusBar,
    QVBoxLayout,
    QWidget,
)

import mycomorph

from .panels.analysis_panel import AnalysisPanel
from .panels.embeddings_panel import EmbeddingsPanel
from .panels.features_panel import FeaturesPanel
from .panels.input_panel import InputMode, InputPanel
from .panels.label_train_panel import LabelTrainPanel
from .panels.layout_panel import LayoutPanel
from .panels.run_panel import RunPanel
from .panels.stage_panels import (
    FluorescentNormalisationPanel,
    FociDetectionPanel,
    FocusPanel,
    SegmentClassifyPanel,
)
from .pipeline.context import BulkRunContext, RunContext
from .pipeline.layout import PlateLayout
from .pipeline.runner import BulkPipelineRunner, PipelineRunner
from .pipeline.stages import EmbeddingsStage
from .ui import icons, tokens, theme
from .ui.elevation import apply_shadow
from .ui.nav_sidebar import NavEntry, NavSidebar, StageStatus
from .updater import ReleaseInfo, UpdateChecker
from .widgets.library_browser import LibraryBrowser
from .widgets.live_preview import LivePreviewPanel


def _gpu_available() -> bool:
    """Best-effort GPU probe for the preflight check.

    Returns True when either CUDA (NVIDIA) or MPS (Apple Silicon) is usable.
    """
    try:
        import torch  # type: ignore
    except Exception:  # noqa: BLE001
        return False
    try:
        if torch.cuda.is_available():
            return True
    except Exception:  # noqa: BLE001
        pass
    try:
        mps = getattr(torch.backends, "mps", None)
        if mps is not None and mps.is_available():
            return True
    except Exception:  # noqa: BLE001
        pass
    return False


# Stage keys used by the sidebar and the (key, panel, label) registry.
NAV_ENTRIES = [
    NavEntry("input",      "Input",              "input"),
    NavEntry("plate",      "Plate layout",       "plate"),
    NavEntry("focus",      "Focus",              "focus",
             indent=True, subheader="Image Processing"),
    NavEntry("segment",    "Segment & Classify", "segment", indent=True),
    NavEntry("features",   "Features",           "features", indent=True),
    NavEntry("fluor_norm", "Fluorescent Normalisation", "fluor_norm",
             indent=True),
    NavEntry("foci_det",   "Foci Detection",     "foci_det", indent=True),
    NavEntry("embeddings", "Embeddings",         "embeddings"),
    NavEntry("run",        "Run",                "run"),
    NavEntry("analysis",   "Analysis",           "analysis", pipeline=False),
]

# Tabs hidden when the user picks "Train embeddings" mode (library-only flow).
_TRAIN_MODE_HIDDEN_TABS = ("plate", "focus", "segment", "features")


class _LabelTrainerWindow(QMainWindow):
    def __init__(self, panel: LabelTrainPanel, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Labeller & Classifier Trainer")
        self.resize(1100, 800)
        self.setCentralWidget(panel)


class _ModelDetailsWindow(QMainWindow):
    def __init__(self, inspector, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Classifier Model Details")
        self.resize(720, 380)
        self.setCentralWidget(inspector)


class _LibraryBrowserWindow(QMainWindow):
    def __init__(self, browser: LibraryBrowser, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Morphology Library Browser")
        self.resize(1100, 600)
        self.setCentralWidget(browser)


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("MycoMorph")
        from ._resources import resource_root
        logo_path = resource_root() / "logo" / "logo.svg"
        if logo_path.exists():
            self.setWindowIcon(QIcon(str(logo_path)))
        self._logo_path = logo_path
        # Aim for enough room to show the 12-column plate uncompressed, but
        # cap to 90% of the available screen so the window fits on smaller
        # (non-retina) laptop displays without overflowing.
        screen = self.screen() or QApplication.primaryScreen()
        avail = screen.availableGeometry() if screen else None
        target_w, target_h = 1600, 1080
        if avail is not None:
            target_w = min(target_w, int(avail.width() * 0.9))
            target_h = min(target_h, int(avail.height() * 0.9))
        self.resize(target_w, target_h)

        self._runner: PipelineRunner | None = None
        self._labeller_window: _LabelTrainerWindow | None = None
        self._model_details_window: _ModelDetailsWindow | None = None
        self._library_browser_window: _LibraryBrowserWindow | None = None
        self._pending_update: ReleaseInfo | None = None

        self.input_panel = InputPanel()
        self.layout_panel = LayoutPanel()
        self.focus_panel = FocusPanel()
        self.segclass_panel = SegmentClassifyPanel()
        self.features_panel = FeaturesPanel()
        self.fluor_norm_panel = FluorescentNormalisationPanel()
        self.foci_det_panel = FociDetectionPanel()
        self.embeddings_panel = EmbeddingsPanel()
        self.run_panel = RunPanel()
        self.analysis_panel = AnalysisPanel()
        self.label_train_panel = LabelTrainPanel()
        self.live_preview = LivePreviewPanel()

        # Convenience aliases — many other places still reference these.
        self.segment_panel = self.segclass_panel.segment_panel
        self.classify_panel = self.segclass_panel.classify_panel

        # Wire panel signals BEFORE building chrome so callbacks can reach widgets.
        # cziPathsSelected fires the multi-CZI list (single-CZI runs send
        # a 1-element list). Connect it BEFORE cziSelected so the layout
        # panel populates from the FULL list before single-CZI consumers
        # (focus/segment) refresh — those only need channel metadata, not
        # the layout. Falls back to the single-CZI signal for legacy callers.
        self.input_panel.cziPathsSelected.connect(self.layout_panel.set_czi_paths)
        self.input_panel.cziPathsSelected.connect(lambda _ps: self._refresh_preview_dirs())
        self.input_panel.cziSelected.connect(self._on_czi_selected)
        self.input_panel.outputDirSelected.connect(self.layout_panel.set_output_dir)
        self.input_panel.outputDirSelected.connect(lambda _p: self._refresh_preview_dirs())
        self.input_panel.outputDirSelected.connect(lambda _p: self._refresh_input_status())
        self.layout_panel.layoutValidityChanged.connect(self._on_layout_validity_changed)
        self.input_panel.resetRequested.connect(self._on_input_reset)
        self.input_panel.channelsChanged.connect(self._on_channels_changed)
        self.input_panel.modeChanged.connect(self._on_input_mode_changed)
        self.input_panel.modeChanged.connect(lambda _m: self._refresh_preview_layouts())
        # Sample labels in the live preview pull condition / reporter
        # / mutant from the plate layout — refresh whenever the user
        # edits a well.
        self.layout_panel._editor.layoutChanged.connect(self._refresh_preview_layouts)
        # Same for bulk-mode label edits (single-file mode also writes
        # through the bulk table model).
        self.input_panel._bulk_model.dataChanged.connect(
            lambda *_args: self._refresh_preview_layouts()
        )
        self.input_panel._bulk_model.modelReset.connect(self._refresh_preview_layouts)
        self.run_panel.runRequested.connect(self._on_run_requested)
        self.run_panel.stageEnablesChanged.connect(self._recompute_stage_readiness)
        self.classify_panel.openLabelTrainerRequested.connect(self._open_label_trainer)
        self.classify_panel.showModelDetailsRequested.connect(self._open_model_details)
        self.features_panel.openLibraryBrowserRequested.connect(self._open_library_browser)
        self.analysis_panel.openLibraryBrowserRequested.connect(self._open_library_browser)
        self.embeddings_panel.openLibraryBrowserRequested.connect(self._open_library_browser)
        # Keep the Analysis panel's library plot pointed at the same
        # library directory the user picks in FeaturesPanel.
        self.features_panel.library_dir.textChanged.connect(self._sync_analysis_library_dir)
        # The Embeddings stage needs ``all_crops.h5``, which is only
        # produced when Features' "Save HDF5 crops" sub-option is on.
        # Mirror that state into the run panel so the Embeddings stage
        # checkbox stays in sync.
        self.features_panel.save_crops.toggled.connect(
            self.run_panel.set_features_save_crops
        )
        self.run_panel.set_features_save_crops(
            self.features_panel.save_crops.isChecked()
        )

        # Stage-state tracking for sidebar status dots.
        self._stage_status: dict[str, StageStatus] = {e.key: StageStatus.IDLE for e in NAV_ENTRIES}
        self._run_active = False
        self.run_panel.stageRunStarted.connect(self._on_stage_run_started)
        self.run_panel.stageRunFinished.connect(self._on_stage_run_finished)
        self.run_panel.runFinishedAll.connect(self._on_run_all_finished)
        self.run_panel.runFailedAll.connect(self._on_run_all_failed)

        self._build_chrome()
        self._apply_card_shadows()
        self._wire_live_preview()
        self._on_input_mode_changed(self.input_panel.mode)
        self._restore_state()
        self._refresh_input_status()

        # Background GitHub Releases poll. No-ops in dev mode (not frozen);
        # deferred so the main window paints before the network call.
        self._update_checker = UpdateChecker(self)
        self._update_checker.updateAvailable.connect(self._on_update_available)
        QTimer.singleShot(2000, self._update_checker.check)

    # ------------------------------------------------------------------ live preview

    def _wire_live_preview(self) -> None:
        """Hand the live preview the option providers + change signals
        it needs to drive the per-FOV pipeline."""
        self.live_preview.wire_pipeline(
            focus_opts=self.focus_panel.opts,
            segment_opts=self.segment_panel.opts,
            classify_opts=self.classify_panel.opts,
            features_opts=self.features_panel.opts,
            phase_channel=lambda: self.input_panel.phase_channel,
            channel_labels=lambda: self.input_panel.channel_labels,
            fluor_norm_opts=self.fluor_norm_panel.opts,
            foci_det_opts=self.foci_det_panel.opts,
            foci_thresholds=self.foci_det_panel.thresholds,
            foci_visible=self.foci_det_panel.foci_visible,
        )
        # Re-render on any option change in the six stage panels.
        self.focus_panel.optionsChanged.connect(self.live_preview.trigger_render)
        self.segment_panel.optionsChanged.connect(self.live_preview.trigger_render)
        self.classify_panel.optionsChanged.connect(self.live_preview.trigger_render)
        self.features_panel.optionsChanged.connect(self.live_preview.trigger_render)
        self.fluor_norm_panel.optionsChanged.connect(self.live_preview.trigger_render)
        self.foci_det_panel.optionsChanged.connect(self.live_preview.trigger_render)
        # Threshold drags hit the fast-path: re-filter cached foci, no
        # detector re-run.
        self.foci_det_panel.thresholdsChanged.connect(
            self.live_preview.apply_thresholds_only,
        )
        # "Show foci on preview" toggle — pure view flip, no re-render.
        self.foci_det_panel.fociVisibilityChanged.connect(
            self.live_preview.set_foci_overlay_visible,
        )
        # Live preview pushes the detected foci's features into the
        # inline panel histograms whenever it runs a detection pass.
        self.live_preview.fociFeaturesAvailable.connect(
            self.foci_det_panel.set_foci_features,
        )

        # FociDetectionPanel's "Label foci…" button opens the label dialog.
        self.foci_det_panel.labelRequested.connect(self._open_foci_label_dialog)

    # ------------------------------------------------------------------ chrome

    def _build_chrome(self) -> None:
        # Header
        self._header = QFrame()
        self._header.setObjectName("header")
        self._header.setFixedHeight(tokens.HEADER_HEIGHT)
        hl = QHBoxLayout(self._header)
        hl.setContentsMargins(tokens.S5, 0, tokens.S5, 0)
        hl.setSpacing(tokens.S3)

        # ── Left: stage context (name + state chip) — no step counter,
        #    no duplicate brand. Branding lives in the sidebar only. ──
        title_col = QVBoxLayout()
        title_col.setContentsMargins(0, 0, 0, 0)
        title_col.setSpacing(0)
        self._stage_title = QLabel("Input")
        self._stage_title.setObjectName("h2")
        title_col.addWidget(self._stage_title)
        self._stage_subhead = QLabel("")
        self._stage_subhead.setObjectName("caption")
        title_col.addWidget(self._stage_subhead)
        hl.addLayout(title_col)

        self._stage_state_chip = QLabel("")
        self._stage_state_chip.setObjectName("themePill")  # reuse the pill style
        self._stage_state_chip.setVisible(False)
        hl.addWidget(self._stage_state_chip)

        # Output-dir chip — surfaces the active run directory; click to open.
        self._outdir_chip = QPushButton("No output directory")
        self._outdir_chip.setObjectName("themePill")
        self._outdir_chip.setCursor(Qt.CursorShape.PointingHandCursor)
        self._outdir_chip.clicked.connect(self._on_outdir_chip_clicked)
        hl.addWidget(self._outdir_chip)

        hl.addStretch(1)

        # ── Right: theme toggle + persistent primary Run action. ──
        self._theme_btn = QPushButton("")
        self._theme_btn.setObjectName("themePill")
        self._theme_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._theme_btn.clicked.connect(self._on_theme_toggle)
        hl.addWidget(self._theme_btn)
        self._sync_theme_btn()

        self._header_run_btn = QPushButton("Run pipeline")
        self._header_run_btn.setObjectName("primary")
        self._header_run_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._header_run_btn.clicked.connect(self._on_header_run_clicked)
        hl.addWidget(self._header_run_btn)

        header_div = QFrame()
        header_div.setObjectName("headerDivider")

        # Sidebar + stack
        self._sidebar = NavSidebar(NAV_ENTRIES)
        self._sidebar.set_gpu_available(_gpu_available())
        self._sidebar.currentChanged.connect(self._on_nav_changed)

        from PyQt6.QtWidgets import QScrollArea, QSizePolicy

        self._stack = QStackedWidget()
        self._stack.setContentsMargins(0, 0, 0, 0)
        # Pages that should fill the page (their own widgets manage stretch).
        FILL_KEYS = {"plate", "segment", "run", "analysis"}
        for entry, panel in zip(NAV_ENTRIES, [
            self.input_panel,
            self.layout_panel,
            self.focus_panel,
            self.segclass_panel,
            self.features_panel,
            self.fluor_norm_panel,
            self.foci_det_panel,
            self.embeddings_panel,
            self.run_panel,
            self.analysis_panel,
        ]):
            wrap = QWidget()
            wv = QVBoxLayout(wrap)
            wv.setContentsMargins(tokens.S5, tokens.S5, tokens.S5, tokens.S5)
            wv.setSpacing(tokens.S3)
            if entry.key in FILL_KEYS:
                # Plate/Segment/Run own their full vertical layout — give them all the space.
                wv.addWidget(panel, stretch=1)
            else:
                # Forms (Input, Focus): wrap in a scroll area pinned to the top so
                # cards don't stretch to fill empty vertical space.
                scroll = QScrollArea()
                scroll.setFrameShape(scroll.Shape.NoFrame)
                scroll.setWidgetResizable(True)
                scroll.setHorizontalScrollBarPolicy(_Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
                inner = QWidget()
                iv = QVBoxLayout(inner)
                iv.setContentsMargins(0, 0, 0, 0)
                iv.setSpacing(tokens.S3)
                panel.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
                iv.addWidget(panel)
                iv.addStretch(1)
                scroll.setWidget(inner)
                wv.addWidget(scroll)
            self._stack.addWidget(wrap)

        # Body row: sidebar | divider | (stack | live preview) inside a
        # horizontal QSplitter so the user can drag the boundary between
        # the option column and the preview column. The sidebar stays
        # fixed-width (a normal QHBoxLayout child) — only the stack and
        # the preview share the splitter.
        body = QWidget()
        body_l = QHBoxLayout(body)
        body_l.setContentsMargins(0, 0, 0, 0)
        body_l.setSpacing(0)
        body_l.addWidget(self._sidebar)
        divider = QFrame()
        divider.setObjectName("sidebarDivider")
        divider.setFrameShape(QFrame.Shape.NoFrame)
        body_l.addWidget(divider)

        self._main_splitter = QSplitter(Qt.Orientation.Horizontal)
        self._main_splitter.setChildrenCollapsible(False)
        # Wider handle than the visible line so the drag area is easy to
        # grab — the stylesheet renders only the central pixel as a line
        # but the hit zone extends a few px on either side.
        self._main_splitter.setHandleWidth(6)
        self._main_splitter.addWidget(self._stack)
        self._main_splitter.addWidget(self.live_preview)
        # Default split: 50/50. Both children get Expanding size policies
        # so Qt distributes available width by stretch factors instead of
        # honouring the stack's larger sizeHint, and we also seed equal
        # initial sizes. ``_user_dragged_splitter`` flips to True if the
        # user manually moves the handle, after which we preserve their
        # ratio rather than snapping back.
        from PyQt6.QtWidgets import QSizePolicy
        self._stack.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding,
        )
        self.live_preview.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding,
        )
        # QStackedWidget reports its minimumSizeHint as the maximum across
        # all child pages — and the Segment & Classify model inspector is
        # 660 px wide, plus padding, so the stack would otherwise refuse
        # to shrink below ~700 px regardless of which tab is showing.
        # Cap the minimum so the user can drag the splitter freely.
        self._stack.setMinimumWidth(200)
        self.live_preview.setMinimumWidth(200)
        self._main_splitter.setSizes([1000, 1000])
        self._main_splitter.setStretchFactor(0, 1)
        self._main_splitter.setStretchFactor(1, 1)
        self._user_dragged_splitter = False
        self._main_splitter.splitterMoved.connect(
            lambda _pos, _idx: setattr(self, "_user_dragged_splitter", True)
        )
        body_l.addWidget(self._main_splitter, stretch=1)

        # Compose
        wrap = QWidget()
        v = QVBoxLayout(wrap)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        v.addWidget(self._header)
        v.addWidget(header_div)
        v.addWidget(self._build_update_banner())
        v.addWidget(body, stretch=1)
        self.setCentralWidget(wrap)

        # Status bar
        sb = QStatusBar()
        self._status_msg = QLabel("Ready.")
        self._status_msg.setObjectName("muted")
        sb.addWidget(self._status_msg, 1)
        self._status_outdir = QLabel("")
        self._status_outdir.setObjectName("caption")
        sb.addPermanentWidget(self._status_outdir)
        self.setStatusBar(sb)

    # ------------------------------------------------------------------ elevation

    def _apply_card_shadows(self) -> None:
        """Attach a subtle drop shadow to every card surface and tighten card heights."""
        from PyQt6.QtWidgets import QFormLayout, QFrame, QGroupBox, QSizePolicy
        for panel in (
            self.input_panel,
            self.layout_panel,
            self.focus_panel,
            self.segclass_panel,
            self.features_panel,
            self.embeddings_panel,
            self.run_panel,
            self.label_train_panel,
        ):
            for box in panel.findChildren(QGroupBox):
                apply_shadow(box, level=1)
                # Pin card height to its content height so short cards don't
                # stretch into seas of empty space.
                box.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum)
            for frame in panel.findChildren(QFrame):
                if frame.objectName() == "card":
                    apply_shadow(frame, level=1)
                    frame.setSizePolicy(
                        QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Maximum
                    )
            # Make form fields (and our helper-wrapped rows) grow horizontally so
            # captions can wrap properly instead of eliding.
            for form in panel.findChildren(QFormLayout):
                form.setFieldGrowthPolicy(
                    QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow
                )

    # ------------------------------------------------------------------ updates

    def _build_update_banner(self) -> QWidget:
        """Thin banner shown when a newer GitHub release exists.

        Hidden by default; ``_on_update_available`` flips it on. Lives
        between the header and the body so it never overlaps panel
        content.
        """
        banner = QFrame()
        banner.setObjectName("updateBanner")
        banner.setVisible(False)
        h = QHBoxLayout(banner)
        h.setContentsMargins(tokens.S5, tokens.S2, tokens.S5, tokens.S2)
        h.setSpacing(tokens.S3)

        self._update_msg = QLabel("")
        self._update_msg.setObjectName("updateBannerMsg")
        self._update_msg.setWordWrap(True)
        h.addWidget(self._update_msg, stretch=1)

        view_btn = QPushButton("View Release")
        view_btn.setObjectName("updateBannerView")
        view_btn.clicked.connect(self._on_update_view_clicked)
        h.addWidget(view_btn)

        dismiss_btn = QPushButton("Dismiss")
        dismiss_btn.setObjectName("updateBannerDismiss")
        dismiss_btn.clicked.connect(self._on_update_dismiss_clicked)
        h.addWidget(dismiss_btn)

        self._update_banner = banner
        return banner

    def _on_update_available(self, info: ReleaseInfo) -> None:
        # Honour a per-version dismissal so we don't nag on every launch
        # for the same release.
        dismissed = self._settings().value("updates/dismissed_version", "", type=str)
        if dismissed == info.version:
            return
        self._pending_update = info
        self._update_msg.setText(
            f"MycoMorph {info.tag} is available — you're running v{mycomorph.__version__}."
        )
        self._update_banner.setVisible(True)

    def _on_update_view_clicked(self) -> None:
        info = self._pending_update
        url = (info.release_url if info else "") or \
            "https://github.com/timdewet/MycoMorph/releases"
        QDesktopServices.openUrl(QUrl(url))
        self._update_banner.setVisible(False)

    def _on_update_dismiss_clicked(self) -> None:
        if self._pending_update is not None:
            self._settings().setValue(
                "updates/dismissed_version", self._pending_update.version
            )
        self._update_banner.setVisible(False)

    # ------------------------------------------------------------------ nav

    def _on_nav_changed(self, idx: int) -> None:
        self._stack.setCurrentIndex(idx)
        if not (0 <= idx < len(NAV_ENTRIES)):
            return
        entry = NAV_ENTRIES[idx]
        if entry.key == "analysis":
            self.analysis_panel.refresh_library()
        # Workspace model, not a wizard: name the stage and its group +
        # current state, rather than a "Step N of M" counter that implied a
        # forced linear order the sidebar never actually enforced.
        self._stage_title.setText(entry.label)
        if entry.subheader:
            self._stage_subhead.setText(entry.subheader)
        elif entry.indent:
            self._stage_subhead.setText("Image Processing")
        elif not entry.pipeline:
            self._stage_subhead.setText("Results")
        else:
            self._stage_subhead.setText("")
        self._update_stage_state_chip(entry.key)
        # Live preview: visible only on the focus / segment / features
        # tabs, hidden on input / plate / run.
        from .widgets.live_preview.panel import RENDER_TAB_KEYS
        show_preview = entry.key in RENDER_TAB_KEYS
        was_visible = self.live_preview.isVisible()
        self.live_preview.setVisible(show_preview)
        if show_preview:
            self.live_preview.set_current_tab(entry.key)
            # Re-impose a 50/50 split when the preview comes back from
            # being hidden — otherwise child size hints in the stack
            # dominate and squeeze it to a sliver. Skip if the user has
            # dragged the handle, so we don't clobber their choice.
            # Defer to QTimer.singleShot(0) so Qt finishes its initial
            # show-driven layout pass first; otherwise our setSizes is
            # immediately overridden by sizeHint-based redistribution.
            if not was_visible and not self._user_dragged_splitter:
                from PyQt6.QtCore import QTimer
                QTimer.singleShot(0, self._reset_main_splitter_to_half)

    def _reset_main_splitter_to_half(self) -> None:
        if self._user_dragged_splitter:
            return
        # Two-step apply: Qt's splitter uses child sizeHints during the
        # initial layout pass that follows setVisible(True), and a
        # synchronous setSizes runs *before* that pass, getting
        # overridden. Pumping events first lets Qt finish the show-
        # driven layout, then we apply our sizes on top.
        QApplication.processEvents()
        total = self._main_splitter.width()
        if total <= 0:
            return
        half = total // 2
        self._main_splitter.setSizes([half, total - half])

    # ------------------------------------------------------------------ persistence

    def _settings(self) -> QSettings:
        return QSettings("MMRU", "MycoMorph")

    def _save_state(self) -> None:
        s = self._settings()
        try:
            s.setValue("window/geometry", self.saveGeometry())
            s.setValue("window/state", self.saveState())
            s.setValue("window/nav_index", self._stack.currentIndex())
            s.setValue("window/main_splitter", self._main_splitter.saveState())
            s.setValue("input_panel", json.dumps(self.input_panel.state()))
            s.setValue("layout_panel", json.dumps(self.layout_panel.state()))
            s.setValue("focus_panel", json.dumps(self.focus_panel.state()))
            s.setValue("segment_panel", json.dumps(self.segment_panel.state()))
            s.setValue("classify_panel", json.dumps(self.classify_panel.state()))
            s.setValue("features_panel", json.dumps(self.features_panel.state()))
            s.setValue("fluor_norm_panel", json.dumps(self.fluor_norm_panel.state()))
            s.setValue("foci_det_panel", json.dumps(self.foci_det_panel.state()))
            s.setValue("embeddings_panel", json.dumps(self.embeddings_panel.state()))
            s.setValue("run_panel", json.dumps(self.run_panel.state()))
            s.setValue("live_preview", json.dumps(self.live_preview.state()))
        except Exception as e:  # noqa: BLE001
            print(f"[mycomorph] Failed to save settings: {e}", file=sys.stderr)

    def _restore_state(self) -> None:
        s = self._settings()
        try:
            geom = s.value("window/geometry")
            if isinstance(geom, QByteArray) and not geom.isEmpty():
                self.restoreGeometry(geom)
        except Exception as e:  # noqa: BLE001
            print(f"[mycomorph] geometry restore failed: {e}", file=sys.stderr)
        try:
            wstate = s.value("window/state")
            if isinstance(wstate, QByteArray) and not wstate.isEmpty():
                self.restoreState(wstate)
        except Exception as e:  # noqa: BLE001
            print(f"[mycomorph] window state restore failed: {e}", file=sys.stderr)
        try:
            split = s.value("window/main_splitter")
            if isinstance(split, QByteArray) and not split.isEmpty():
                self._main_splitter.restoreState(split)
        except Exception as e:  # noqa: BLE001
            print(f"[mycomorph] splitter restore failed: {e}", file=sys.stderr)
        try:
            raw = s.value("live_preview")
            if raw:
                self.live_preview.restore_state(json.loads(raw))
        except Exception as e:  # noqa: BLE001
            print(f"[mycomorph] live_preview restore failed: {e}", file=sys.stderr)
        for key, panel in (
            ("input_panel",    self.input_panel),
            ("layout_panel",   self.layout_panel),
            ("focus_panel",    self.focus_panel),
            ("segment_panel",  self.segment_panel),
            ("classify_panel", self.classify_panel),
            ("features_panel", self.features_panel),
            ("fluor_norm_panel", self.fluor_norm_panel),
            ("foci_det_panel", self.foci_det_panel),
            ("embeddings_panel", self.embeddings_panel),
            ("run_panel",      self.run_panel),
        ):
            raw = s.value(key)
            if not raw:
                continue
            try:
                panel.restore_state(json.loads(raw))
            except Exception as e:  # noqa: BLE001
                print(f"[mycomorph] {key} restore failed: {e}", file=sys.stderr)
        # InputPanel.restore_state emits outputDirSelected (which auto-loads
        # plate_layout.csv) BEFORE cziSelected (which calls
        # LayoutPanel.set_czi_path → PlateLayout.from_czi, building an
        # empty-conditions layout that clobbers the CSV-loaded one). Re-import
        # the CSV here, after both have fired, so the previous run's plate
        # layout (conditions / reporters / mutants) survives app restart.
        out = self.input_panel.output_dir
        if out is not None and Path(out).exists():
            self.layout_panel.set_output_dir(out)

        # Now that all panels and the output dir are restored, paint the
        # initial sidebar readiness state.
        self._recompute_stage_readiness()

        # Always start on the Input tab — it's the natural beginning of
        # the workflow and avoids reopening on a stale stage from last session.
        input_idx = self._sidebar.index_of("input")
        if input_idx >= 0:
            self._sidebar.set_current(input_idx)

    def closeEvent(self, event) -> None:  # noqa: N802 (Qt API)
        self._save_state()
        super().closeEvent(event)

    # ---------------------------------------------------------------- preflight

    def _preflight_ok(self, out: Path, enables: dict[str, bool]) -> bool:
        blocking: list[str] = []
        warnings: list[str] = []

        if enables.get("Classify") and not enables.get("Segment"):
            seg_dir = out / "02_segment"
            if not seg_dir.exists() or not any(seg_dir.iterdir()):
                blocking.append(
                    "Classify is enabled but Segment is disabled and no "
                    f"segment output exists at {seg_dir}."
                )

        if enables.get("Segment") and not enables.get("Focus"):
            focus_candidates = [
                out / "01_split_and_focused",
                out / "01_focus",
                out / "01_split",
            ]
            has_focus = any(d.exists() and any(d.iterdir()) for d in focus_candidates)
            if not has_focus:
                blocking.append(
                    "Segment is enabled but Focus is disabled and no focused "
                    "output exists in any of:\n  "
                    + "\n  ".join(str(d) for d in focus_candidates)
                )

        if enables.get("Features") and not (
            enables.get("Segment") or enables.get("Classify")
        ):
            features_candidates = [out / "03_classify", out / "02_segment"]
            has_input = any(d.exists() and any(d.iterdir()) for d in features_candidates)
            if not has_input:
                blocking.append(
                    "Features is enabled but neither Segment nor Classify is "
                    "enabled, and no upstream output exists in any of:\n  "
                    + "\n  ".join(str(d) for d in features_candidates)
                )

        if enables.get("Segment") and self.segment_panel.opts().gpu:
            if not _gpu_available():
                warnings.append(
                    "GPU requested for segmentation but no CUDA or MPS device "
                    "was found; the run will fall back to CPU (much slower)."
                )

        if (out.exists() and any(out.iterdir())
                and not self.run_panel.reuse_existing.isChecked()):
            warnings.append(
                f"Output directory already contains files and 'Reuse existing' "
                f"is off. Existing files in {out} may be overwritten."
            )

        if self.input_panel.mode in (InputMode.SINGLE_FILE, InputMode.BULK):
            issues = self.input_panel.bulk_layout.validate()
            if issues:
                blocking.extend(issues)

        if blocking:
            QMessageBox.critical(self, "Cannot run", "\n\n".join(blocking))
            return False

        if warnings:
            for w in warnings:
                self.run_panel.log.log(f"⚠ {w}", level="warning")
            answer = QMessageBox.question(
                self, "Run with warnings?",
                "\n\n".join(warnings) + "\n\nContinue anyway?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if answer != QMessageBox.StandardButton.Yes:
                return False
        return True

    # ---------------------------------------------------------------- slots

    def _on_input_mode_changed(self, mode: InputMode) -> None:
        """Toggle which sidebar tabs make sense for the chosen workflow.

        - Plate-layout: only in single-plate mode.
        - Image-processing stages (focus/segment/features): hidden in
          train-embeddings mode, where there's no CZI to process.
        - The Embeddings panel switches into "train-only" mode (hides the
          Use-existing-model option) when this workflow is active.
        """
        train_mode = mode == InputMode.TRAIN_EMBEDDINGS

        # Plate is single-plate-only AND must be hidden in train mode.
        plate_visible = mode == InputMode.SINGLE_PLATE and not train_mode
        self._sidebar.set_visible("plate", plate_visible)
        plate_idx = self._sidebar.index_of("plate")
        if 0 <= plate_idx < self._stack.count():
            self._stack.widget(plate_idx).setEnabled(plate_visible)

        # Image-processing tabs: hidden whenever we're training from library.
        for key in ("focus", "segment", "features", "fluor_norm", "foci_det"):
            self._sidebar.set_visible(key, not train_mode)
            i = self._sidebar.index_of(key)
            if 0 <= i < self._stack.count():
                self._stack.widget(i).setEnabled(not train_mode)

        # If the currently selected page is now hidden, jump back to Input.
        cur_idx = self._stack.currentIndex()
        if 0 <= cur_idx < len(NAV_ENTRIES):
            cur_key = NAV_ENTRIES[cur_idx].key
            if cur_key not in self._sidebar._visible_keys:
                self._sidebar.set_current(self._sidebar.index_of("input"))

        self.embeddings_panel.set_train_only_mode(train_mode)
        self.run_panel.set_train_only_mode(train_mode)

        self._refresh_input_status()
        # Step counter changes when the visible set changes.
        self._on_nav_changed(self._stack.currentIndex())

    def _on_layout_validity_changed(self, ok: bool) -> None:
        # Sidebar dots are reserved for real run state (running/done/errored);
        # form readiness no longer paints them.
        self._recompute_stage_readiness()

    def _on_input_reset(self) -> None:
        # Wipe downstream state so the user really is starting from scratch.
        self.layout_panel.clear()
        self._refresh_input_status()
        self._refresh_preview_dirs()

    def _refresh_input_status(self) -> None:
        # Input never carries a status dot — its readiness is conveyed by
        # field state, not by the sidebar.
        self._recompute_stage_readiness()

    # ---------------------------------------------------------------- readiness

    # Per-stage output directories (relative to the run output dir) and the
    # nav key of the upstream stage each one depends on. "done" is read off
    # disk; "ready/blocked" is derived from the upstream's state. Mirrors the
    # dependency rules enforced in _preflight_ok.
    _STAGE_OUTPUT_DIRS = {
        "focus":      ("01_split_and_focused", "01_focus", "01_split"),
        "segment":    ("02_segment", "03_classify"),
        "features":   ("04_features",),
        "fluor_norm": ("04b_fluorescent_normalisation",),
        "foci_det":   ("04c_foci_detection",),
        "embeddings": ("embeddings",),
    }
    _STAGE_UPSTREAM = {
        "focus":      None,          # first processing stage — depends on input
        "segment":    "focus",
        "features":   "segment",
        "fluor_norm": "segment",
        "foci_det":   "fluor_norm",
        "embeddings": "features",
    }

    def _dir_has_content(self, out, name: str) -> bool:
        d = out / name
        try:
            return d.exists() and any(d.iterdir())
        except Exception:  # noqa: BLE001
            return False

    def _stage_done_on_disk(self, key: str, out) -> bool:
        return any(
            self._dir_has_content(out, n)
            for n in self._STAGE_OUTPUT_DIRS.get(key, ())
        )

    def _recompute_stage_readiness(self) -> None:
        """Paint a quiet pre-run status dot on every processing stage.

        done   — output exists on disk
        ready   — its upstream is satisfied (done, or input is ready for the
                  first stage) so the stage can be run now
        blocked — upstream output missing; running now would fail preflight
        idle    — no input selected yet / not applicable

        These are kept visually distinct from the loud run-state dots
        (running / done / errored), which the run lifecycle owns. We never
        repaint while a run is active so we don't clobber those.
        """
        if getattr(self, "_run_active", False):
            return
        if not hasattr(self, "_sidebar"):
            return
        out = self.input_panel.output_dir
        input_ready = out is not None and self.input_panel.has_czi_input
        # Header Run is only actionable once there's something to run.
        self._header_run_btn.setEnabled(input_ready)

        status_by_key: dict[str, StageStatus] = {}
        for key in self._STAGE_OUTPUT_DIRS:
            if not input_ready:
                st = StageStatus.IDLE
            elif self._stage_done_on_disk(key, out):
                st = StageStatus.DONE
            else:
                up = self._STAGE_UPSTREAM[key]
                upstream_ok = up is None or self._stage_done_on_disk(up, out)
                st = StageStatus.READY if upstream_ok else StageStatus.BLOCKED
            status_by_key[key] = st
            self._stage_status[key] = st
            self._sidebar.set_status(key, st)

        # Refresh the header chip for whichever stage is showing.
        cur = self._sidebar._items.index(
            next((it for it in self._sidebar._items if it.isChecked()),
                 self._sidebar._items[0])
        ) if self._sidebar._items else 0
        if 0 <= cur < len(NAV_ENTRIES):
            self._update_stage_state_chip(NAV_ENTRIES[cur].key)
        self._refresh_outdir_chip()

    _STATE_CHIP_TEXT = {
        StageStatus.DONE:    "Done",
        StageStatus.READY:   "Ready to run",
        StageStatus.BLOCKED: "Needs upstream output",
        StageStatus.RUNNING: "Running…",
        StageStatus.ERROR:   "Failed",
        StageStatus.IDLE:    "",
    }

    def _update_stage_state_chip(self, key: str) -> None:
        st = self._stage_status.get(key, StageStatus.IDLE)
        text = self._STATE_CHIP_TEXT.get(st, "")
        self._stage_state_chip.setText(text)
        self._stage_state_chip.setVisible(bool(text))

    def _refresh_outdir_chip(self) -> None:
        out = self.input_panel.output_dir
        if out is None:
            self._outdir_chip.setText("No output directory")
            self._outdir_chip.setEnabled(False)
        else:
            self._outdir_chip.setText(f"📁 {out.name}")
            self._outdir_chip.setToolTip(str(out))
            self._outdir_chip.setEnabled(True)

    def _on_outdir_chip_clicked(self) -> None:
        out = self.input_panel.output_dir
        if out is not None and Path(out).exists():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(out)))

    def _on_header_run_clicked(self) -> None:
        # Jump to the Run tab so the user sees the log/stepper, then start.
        run_idx = self._sidebar.index_of("run")
        if run_idx >= 0:
            self._sidebar.set_current(run_idx)
        self.run_panel.runRequested.emit()

    def _on_theme_toggle(self) -> None:
        order = [theme.ThemeMode.AUTO, theme.ThemeMode.LIGHT, theme.ThemeMode.DARK]
        cur = theme.theme_mode()
        nxt = order[(order.index(cur) + 1) % len(order)] if cur in order else theme.ThemeMode.LIGHT
        theme.set_theme_override(nxt)
        self._sync_theme_btn()

    def _sync_theme_btn(self) -> None:
        glyph = {
            theme.ThemeMode.AUTO:  "◐ Auto",
            theme.ThemeMode.LIGHT: "☀ Light",
            theme.ThemeMode.DARK:  "☾ Dark",
        }.get(theme.theme_mode(), "◐ Auto")
        self._theme_btn.setText(glyph)

    def _on_channels_changed(self) -> None:
        ch = self.input_panel.phase_channel
        self.focus_panel.set_phase_channel(ch)
        self.label_train_panel.set_phase_channel(ch)
        self.live_preview.set_phase_channel(ch)
        labels = self.input_panel.channel_labels or []
        self.features_panel.set_channels(list(labels))
        self.fluor_norm_panel.set_channels(list(labels))
        self.foci_det_panel.set_channels(list(labels))
        # Foci panels operate on fluorescence only — hide the phase row.
        phase_idx = ch if isinstance(ch, int) else None
        self.fluor_norm_panel.set_phase_channel(phase_idx)
        self.foci_det_panel.set_phase_channel(phase_idx)

    def _on_czi_selected(self, czi_path) -> None:
        try:
            from mycomorph.core.split_czi_plate import _read_czi_pixels_per_um
            px = _read_czi_pixels_per_um(czi_path)
        except Exception:  # noqa: BLE001
            px = None
        self.segclass_panel.set_detected_pixels_per_um(px)
        self._refresh_preview_dirs()
        self._refresh_input_status()

    def _refresh_preview_dirs(self) -> None:
        out = self.input_panel.output_dir
        if out is not None:
            self._status_outdir.setText(str(out))
        else:
            self._status_outdir.setText("")
        # Always feed the live preview the up-to-date list of CZIs from
        # the Input panel — the Focus tab pulls samples from this list.
        self.live_preview.set_czi_paths(self._all_input_czi_paths())
        # And the layout context, so samples can be labelled by
        # well / condition / reporter rather than raw filename.
        self._refresh_preview_layouts()
        # Push the output dir + run id into the FociDetectionPanel so
        # the inline "Save filter" action knows where to write.
        self.foci_det_panel.set_output_context(
            out, out.name if out is not None else "",
        )
        if out is None:
            self.live_preview.set_search_dirs([])
            self.label_train_panel.set_segment_dir(None)
            self.foci_det_panel.set_label_button_enabled(False)
            return
        candidates = [
            out / "01_split_and_focused",
            out / "01_focus",
            out / "01_split",
        ]
        self.live_preview.set_search_dirs([d for d in candidates if d.exists()])
        seg_dir = out / "02_segment"
        self.label_train_panel.set_segment_dir(seg_dir if seg_dir.exists() else None)
        # Enable the foci-label button if Foci Detection has produced output.
        foci_dir = out / "04c_foci_detection"
        has_foci = foci_dir.exists() and any(foci_dir.glob("*.parquet"))
        self.foci_det_panel.set_label_button_enabled(has_foci)

    def _open_foci_label_dialog(self) -> None:
        """Open the modal foci-labelling dialog rooted at the current output dir."""
        out = self.input_panel.output_dir
        if out is None:
            QMessageBox.warning(
                self, "No output directory",
                "Select an output directory in the Input panel first.",
            )
            return
        foci_dir = out / "04c_foci_detection"
        if not foci_dir.exists() or not any(foci_dir.glob("*.parquet")):
            QMessageBox.warning(
                self, "Nothing to label",
                f"No foci-detection parquets at {foci_dir}. "
                "Run the Foci Detection stage first.",
            )
            return
        from .widgets.foci_label_dialog import FociLabelDialog
        dlg = FociLabelDialog(
            output_dir=out,
            channel_labels=list(self.input_panel.channel_labels or []),
            run_id=out.name,
            parent=self,
        )
        dlg.exec()


    def _refresh_preview_layouts(self) -> None:
        """Hand the live preview the current plate / bulk layout DataFrames.

        Called whenever any of the layouts change so the sample combo
        re-renders with the latest condition / reporter / mutant labels.

        Important: read ``self.input_panel._bulk_layout`` (the private
        attribute), not the public ``bulk_layout`` property. The latter
        calls ``_sync_single_file_to_layout()``, which fires
        ``_bulk_model.modelReset`` — the same signal that triggers
        this method — and creates an infinite loop.
        """
        try:
            plate_df = self.layout_panel.layout_model.df
        except Exception:  # noqa: BLE001
            plate_df = None
        try:
            bulk_df = self.input_panel._bulk_layout.df
        except Exception:  # noqa: BLE001
            bulk_df = None
        self.live_preview.set_layouts(
            self.input_panel.mode.value, plate_df, bulk_df,
        )

    def _all_input_czi_paths(self) -> list[Path]:
        """Aggregate every CZI the user has lined up across input modes.

        Single-plate uses the plate CZI list; single-file/bulk pull from
        the bulk layout. Used to seed the live preview's Focus-tab
        sample combo regardless of input mode.
        """
        mode = self.input_panel.mode
        if mode == InputMode.SINGLE_PLATE:
            return [Path(p) for p in self.input_panel.czi_paths]
        try:
            df = self.input_panel.bulk_layout.df
            return [Path(p) for p in df["czi_path"].astype(str) if p]
        except Exception:  # noqa: BLE001
            return []

    def _open_label_trainer(self) -> None:
        if self._labeller_window is None:
            self._labeller_window = _LabelTrainerWindow(self.label_train_panel, parent=self)
        self._labeller_window.show()
        self._labeller_window.raise_()
        self._labeller_window.activateWindow()

    def _open_model_details(self) -> None:
        if self._model_details_window is None:
            self._model_details_window = _ModelDetailsWindow(
                self.classify_panel.inspector, parent=self,
            )
        self._model_details_window.show()
        self._model_details_window.raise_()
        self._model_details_window.activateWindow()

    def _sync_analysis_library_dir(self, text: str) -> None:
        text = (text or "").strip()
        self.analysis_panel.set_library_dir(Path(text) if text else None)

    def _resolve_control_labels(self, mode: InputMode) -> str:
        """Pick the user-typed control labels from the appropriate panel.

        Plate runs prefer the LayoutPanel's value (it lives next to the
        well editor), falling back to the InputPanel. Single-file / bulk
        runs only use the InputPanel.
        """
        if mode == InputMode.SINGLE_PLATE:
            return (self.layout_panel.control_labels
                    or self.input_panel.control_labels)
        return self.input_panel.control_labels

    def _open_library_browser(self) -> None:
        # Use the library_dir currently configured in the FeaturesPanel.
        lib_dir_text = self.features_panel.library_dir.text().strip()
        lib_dir = Path(lib_dir_text) if lib_dir_text else None
        if self._library_browser_window is None:
            browser = LibraryBrowser(library_dir=lib_dir, parent=self)
            # Push library mutations (import / edit / remove) back to the
            # Analysis page so its plot stays in sync.
            browser.libraryChanged.connect(
                self.analysis_panel.on_library_changed_external
            )
            self._library_browser_window = _LibraryBrowserWindow(browser, parent=self)
        else:
            self._library_browser_window.centralWidget().set_library_dir(lib_dir)
        self._library_browser_window.show()
        self._library_browser_window.raise_()
        self._library_browser_window.activateWindow()

    # ---------------------------------------------------------------- run state -> sidebar

    # Map runner stage names → sidebar nav keys so per-stage dots light up.
    # Split shares the Focus tab (they live in the Image Processing group);
    # Classify shares the Segment tab.
    _STAGE_TO_NAV = {
        "Split":      "focus",
        "Focus":      "focus",
        "Segment":    "segment",
        "Classify":   "segment",
        "Features":   "features",
        "Embeddings": "embeddings",
    }

    def _on_stage_run_started(self, name: str) -> None:
        self._run_active = True
        self._header_run_btn.setEnabled(False)
        self._header_run_btn.setText("Running…")
        self._sidebar.set_status("run", StageStatus.RUNNING)
        nav_key = self._STAGE_TO_NAV.get(name)
        if nav_key:
            self._sidebar.set_status(nav_key, StageStatus.RUNNING)
        self._status_msg.setText(f"Running: {name}")

    def _on_stage_run_finished(self, name: str, _n: int) -> None:
        nav_key = self._STAGE_TO_NAV.get(name)
        if nav_key:
            self._sidebar.set_status(nav_key, StageStatus.DONE)
        self._status_msg.setText(f"Finished: {name}")

    def _on_run_all_finished(self, _manifest: object) -> None:
        self._run_active = False
        self._header_run_btn.setEnabled(True)
        self._header_run_btn.setText("Run pipeline")
        self._sidebar.set_status("run", StageStatus.DONE)
        self._status_msg.setText("Run complete.")
        # Outputs now exist on disk for stages that just ran — re-evaluate so
        # any newly-produced output sets its sidebar dot green.
        self._recompute_stage_readiness()
        # Foci Detection may have just produced parquets; refresh the
        # Label-foci button enable state so the user can label without
        # having to re-pick the output directory.
        self._refresh_preview_dirs()
        # The Features stage may have just registered a new run in the
        # feature library — refresh the Analysis page's interactive plot
        # so it reflects the new data on next visit (or right now if the
        # user is already on the Analysis tab).
        try:
            self.analysis_panel.on_pipeline_finished()
        except Exception:  # noqa: BLE001
            pass

    def _on_run_all_failed(self, msg: str) -> None:
        self._run_active = False
        self._header_run_btn.setEnabled(True)
        self._header_run_btn.setText("Run pipeline")
        self._sidebar.set_status("run", StageStatus.ERROR)
        self._status_msg.setText(f"Failed: {msg}")
        self._recompute_stage_readiness()

    def _on_run_requested(self) -> None:
        out = self.input_panel.output_dir
        if out is None:
            QMessageBox.warning(self, "Missing output", "Select an output directory.")
            return

        enables = self.run_panel.stage_enables()
        mode = self.input_panel.mode

        if mode == InputMode.TRAIN_EMBEDDINGS:
            # Library-only training: skip preflight (no CZIs/layout to validate),
            # build a minimal context, and run only the Embeddings stage.
            embeddings_opts = self.embeddings_panel.opts()
            ctx = RunContext(
                czi_path=Path(),
                czi_paths=[],
                output_dir=out,
                layout=PlateLayout.empty(),
                do_split=False,
                do_focus=False,
                do_segment=False,
                do_classify=False,
                do_features=False,
                do_embeddings=True,
                embeddings_opts=embeddings_opts,
            )
            self._runner = PipelineRunner(
                ctx,
                reuse_existing=False,
                stages=[EmbeddingsStage()],
            )
            self._wire_runner_signals()
            return

        if not self._preflight_ok(out, enables):
            return

        if mode == InputMode.SINGLE_PLATE:
            czi = self.input_panel.czi_path
            czi_paths = self.input_panel.czi_paths
            if czi is None or not czi_paths:
                QMessageBox.warning(self, "Missing input", "Select a CZI file.")
                return
            features_opts = self.features_panel.opts()
            features_opts.control_labels = self._resolve_control_labels(mode)
            ctx = RunContext(
                czi_path=czi,
                czi_paths=list(czi_paths),
                output_dir=out,
                layout=self.layout_panel.layout_model,
                do_split=enables["Split"],
                do_focus=enables["Focus"],
                do_segment=enables["Segment"],
                do_classify=enables["Classify"],
                do_features=enables.get("Features", False),
                do_fluorescent_normalisation=enables.get(
                    "Fluorescent Normalisation", False
                ),
                do_foci_detection=enables.get("Foci Detection", False),
                do_embeddings=enables.get("Embeddings", False),
                focus_opts=self.focus_panel.opts(),
                segment_opts=self.segment_panel.opts(),
                classify_opts=self.classify_panel.opts(),
                features_opts=features_opts,
                fluorescent_normalisation_opts=self.fluor_norm_panel.opts(),
                foci_detection_opts=self.foci_det_panel.opts(),
                embeddings_opts=self.embeddings_panel.opts(),
                phase_channel=self.input_panel.phase_channel,
                channel_labels=self.input_panel.channel_labels,
            )
            self._runner = PipelineRunner(
                ctx, reuse_existing=self.run_panel.reuse_existing.isChecked()
            )
        else:
            bulk = self.input_panel.bulk_layout
            issues = bulk.validate()
            if issues:
                QMessageBox.warning(self, "Validation failed", "\n".join(issues))
                return
            entries = bulk.active_rows().to_dict(orient="records")
            features_opts = self.features_panel.opts()
            features_opts.control_labels = self._resolve_control_labels(mode)
            ctx = BulkRunContext(
                czi_entries=entries,
                output_dir=out,
                do_focus=enables["Focus"],
                do_segment=enables["Segment"],
                do_classify=enables["Classify"],
                do_features=enables.get("Features", False),
                do_fluorescent_normalisation=enables.get(
                    "Fluorescent Normalisation", False
                ),
                do_foci_detection=enables.get("Foci Detection", False),
                do_embeddings=enables.get("Embeddings", False),
                focus_opts=self.focus_panel.opts(),
                segment_opts=self.segment_panel.opts(),
                classify_opts=self.classify_panel.opts(),
                features_opts=features_opts,
                fluorescent_normalisation_opts=self.fluor_norm_panel.opts(),
                foci_detection_opts=self.foci_det_panel.opts(),
                embeddings_opts=self.embeddings_panel.opts(),
                phase_channel=self.input_panel.phase_channel,
                channel_labels=self.input_panel.channel_labels,
            )
            self._runner = BulkPipelineRunner(
                ctx, reuse_existing=self.run_panel.reuse_existing.isChecked()
            )

        self._wire_runner_signals()

    def _wire_runner_signals(self) -> None:
        """Connect ``self._runner``'s signals to the run panel and start it."""
        self._runner.stagesPlanned.connect(self.run_panel.on_stages_planned)
        self._runner.stageStarted.connect(self.run_panel.on_stage_started)
        self._runner.stageProgress.connect(self.run_panel.on_stage_progress)
        self._runner.stageFinished.connect(self.run_panel.on_stage_finished)
        self._runner.runFinished.connect(self.run_panel.on_run_finished)
        self._runner.runFailed.connect(self.run_panel.on_run_failed)
        self.run_panel.stopRequested.connect(self._runner.request_stop)

        self.run_panel.run_btn.setEnabled(False)
        self.run_panel.stop_btn.setEnabled(True)

        def _end(*_args: object) -> None:
            self.run_panel.run_btn.setEnabled(True)
            self.run_panel.stop_btn.setEnabled(False)

        self._runner.runFinished.connect(_end)
        self._runner.runFailed.connect(_end)
        self._runner.start()
