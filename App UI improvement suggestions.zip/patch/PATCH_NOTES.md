# MycoMorph UI patch — navigation, stage status, header

Implements concept suggestions **#1 (wizard → workspace)**, **#2 (stage status)**,
and **#3 (header rework)**. Three files change; drop each over the same path in
your repo:

```
patch/src/mycomorph/gui/ui/icons.py          → src/mycomorph/gui/ui/icons.py
patch/src/mycomorph/gui/ui/nav_sidebar.py    → src/mycomorph/gui/ui/nav_sidebar.py
patch/src/mycomorph/gui/main_window.py       → src/mycomorph/gui/main_window.py
```

No new dependencies, no API/signature changes to public methods. All edits are
additive or local to the chrome.

---

## #2 — Stage status in the sidebar

**`icons.py`**
- `status-ready` glyph changed to `mdi.circle-outline` (a coloured ring, matching
  the concept) and a new `status-blocked` glyph (`mdi.circle-medium`, amber).

**`nav_sidebar.py`**
- New `StageStatus.BLOCKED` ("needs upstream output") + its entry in
  `_STATUS_TO_ICON` (warning/amber).
- `_StatusBadge.set_status` now renders **every** state except `DISABLED`
  (previously only running/done/error showed). Pre-run states use quiet glyphs
  (hollow ring / coloured ring / amber dot) so they never compete with the loud
  run-state dots — that visual separation is what avoids the "mixed signals"
  problem that got the old readiness painting removed.

**`main_window.py`**
- `_recompute_stage_readiness()` (was a no-op) now paints each processing stage:
  - **done** — output dir exists on disk
  - **ready** — upstream satisfied, can run now
  - **blocked** — upstream output missing (would fail preflight)
  - **idle** — no input selected yet
- Dependency table (`_STAGE_UPSTREAM`) and output dirs (`_STAGE_OUTPUT_DIRS`)
  mirror the rules already enforced in `_preflight_ok` and the dir scheme in
  `context.py` (`01_split_and_focused` / `02_segment` / `03_classify` /
  `04_features` / `04b_fluorescent_normalisation` / `04c_foci_detection`).
- Guarded with `self._run_active` so it never clobbers a live run's dots.

## #1 — Wizard → workspace

**`main_window.py`**
- Dropped the `"Step N of M · …"` breadcrumb. `_on_nav_changed` now sets a stage
  **title** + **group subhead** (e.g. "Focus" / "Image Processing") and a state
  chip, instead of a counter that implied a linear order the sidebar never
  enforced. The visible-index / step bookkeeping is gone.

## #3 — Header rework

**`main_window.py`** — header rebuilt:
- **Removed** the duplicate `"MycoMorph"` brand label + 50px logo (branding now
  lives only in the sidebar).
- **Left:** stage title + group subhead, a **state chip** (reuses the existing
  but previously-unplaced `#themePill` QSS), and an **output-dir chip** (click →
  opens the folder).
- **Right:** a **theme toggle** (cycles Auto → Light → Dark via the existing
  `theme.set_theme_override`) and a **persistent “Run pipeline”** primary button
  (jumps to the Run tab and emits `runRequested`). The button disables while a
  run is active and when no input is loaded.

---

## Things to confirm before shipping

- **Status taxonomy wording** — chip/legend text ("Needs upstream output") vs.
  naming the specific blocking stage.
- **`embeddings` output dir** — I used `"embeddings"` as its on-disk marker;
  verify against your library layout (it wasn't in `context.py`'s dir props).
- **fluor_norm / foci_det upstream** — modelled as depending on `segment` and
  `fluor_norm` respectively, per `stages.py`. Confirm that matches intended UX
  (e.g. whether foci detection should show "ready" off raw segment output).
- Not runtime-tested here (no PyQt env) — please smoke-test launch + a dry run.
